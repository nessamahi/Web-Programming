<?php
/*** Create a table through PHP Script ***/

$servername = "localhost";
$username = "imahi1";
$password = "imahi1";
$dbname = "imahi1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE Movie (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
moviename VARCHAR(30) NOT NULL,
genre VARCHAR(30) NOT NULL,
year INT(4) NOT NULL,
book VARCHAR(10) NOT NULL,
mystatus VARCHAR(10),
description VARCHAR(10000000),
comments VARCHAR(10000000),
file_name VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
status enum('1', '0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";

if ($conn->query($sql) === TRUE) {
  echo "Table Movie created successfully!";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
