
<?php
$servername = "localhost";
$username = "imahi1";
$password = "imahi1";
$dbname = "imahi1";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}

$sql = "UPDATE Movie SET genre='$_POST[genre]',year='$_POST[year]',book='$_POST[book]',mystatus='$_POST[mystatus]',description='$_POST[description]',comments='$_POST[comments]' WHERE moviename='$_POST[moviename]'";
if (mysqli_query($conn, $sql)) {
echo "Update record successfully";
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>

