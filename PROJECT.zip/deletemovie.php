
<?php
$servername = "localhost";
$username = "imahi1";
$password = "imahi1";
$dbname = "imahi1";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}

$sql = "delete from Movie where moviename='$_POST[moviename]'";
if (mysqli_query($conn, $sql)) {
echo "Delete record successfully";
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
