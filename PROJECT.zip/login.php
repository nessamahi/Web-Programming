<?php session_start(); /* Starts the session */
/* Check Login form submitted */if(isset($_POST['Submit'])){
/* Define username and associated password array */$logins = array('imahi1' => 'XYZ876','ncasturi1' => 'ABC176','username2' => '125YTH');

/* Check and assign submitted Username and Password to new variable */$Username = isset($_POST['Username']) ? $_POST['Username'] : '';
$Password = isset($_POST['Password']) ? $_POST['Password'] : '';

/* Check Username and Password existence in defined array */if (isset($logins[$Username]) && $logins[$Username] == $Password){
/* Success: Set session variables and redirect to Protected page  */$_SESSION['UserData']['Username']=$logins[$Username];
header("location:mainPage.html");
exit;
} else {
/*Unsuccessful attempt: Set error message */$msg="<span style='color:red'>Invalid Login Details</span>";
}
}
?>


<!DOCTYPE html>
<html>
<head>
<style>
        #main-nav {
            padding: 50px;
            margin: 0px;
        }

        .header__container {
            display: flex;
            justify-content: space-between;
            background-color: #F7F7F7;
        }

        .header-logo-link > img {
            width: 50px;
        }

        nav.header-nav {
            display: flex;
        }

        .header-home {
            padding: 12px 30px;
            border: 1px solid black;
            margin-right: 20px;
            cursor: pointer;
            text-decoration: none;
            color: black;
        }

        .header-admin {
            padding: 12px 30px;
            border: 1px solid black;
            cursor: pointer;
            text-decoration: none;
            color: black;
        }

        #main-content {
            margin-top: 15px;
            padding: 50px;
        }

        .main-content__header {
            display: flex;
            justify-content: center;
        }

        .box-design {
            width: 150px;
            padding: 10px 12px;
            height: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            border: 1px solid black;
        }

        .main-content__details-and-search__wrapper {
            margin-top: 15px;
            display: flex;
            justify-content: space-around;
        }

        .main-content__search {
            display: flex;
        }

        .search-field.box-design {
            padding: 16px 13px;
            width: 200px;
        }

        .search-submit {
            height: 34px;
            margin-left: 10px;
            padding: 6px 12px;
            background: lightgrey;
            border: 1px solid black;
            cursor: pointer;
        }

        .movie-slider {
            margin-top: 50px;
            display: flex;
            justify-content: center;
        }

        .movie-container {
            padding: 30px 50px;
            border: 1px solid black;
            background: #f7f7f7;
            width: 90% !important;
        }

        .movie-name {
            margin: 18px 20px;
            font-size: 18px;
            font-weight: 600;
        }

        .movie-details {
            margin: 0 20px;
            display: flex;
        }

        .movie-left-box {
            margin-right: 30px;
        }

        .movie-left-box > img {
            width: 200px;
        }

        .movie-description {
            text-align: left;
            margin-bottom: 25px;
        }

        .movie-details-container {
            display: flex;
            justify-content: space-around;
            margin-bottom: 24px;
        }

        .movie-my-status {
            margin-bottom: 25px;
        }

        .slick-prev, .slick-next {
            background-color: darkgrey !important;
        }

    </style>
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; connect-src 'self';font-src 'self'; img-src 'self' data: https:; style-src 'self' ; script-src 'self'">
</head>

<body>
<div id="main-nav">
    <div class="header__container">
        <div class="header-logo">
            <a  class="header-logo-link" title="Logo" aria-label="Logo"><img
                    src="catlogo.png"></a>
        </div>

        <div class="header-nav-container">
            <nav class="header-nav" aria-label="Navigation" role="navigation">
                <a class="header-home" href="homePage.php">Home</a>
                <a class="header-admin" href="login.php">Admin</a>
            </nav>
        </div>
    </div>
</div>


<form action="" method="post" name="Login_Form">
  <table width="400" border="0" align="center" cellpadding="5" cellspacing="1" class="Table">
    <?php if(isset($msg)){?>
    <tr>
      <td colspan="2" align="center" valign="top"><?php echo $msg;?></td>
    </tr>
    <?php } ?>
    <tr>
      <td colspan="2" align="left" valign="top"><h3>Login</h3></td>
    </tr>
    <tr>
      <td align="right" valign="top">Username</td>
      <td><input name="Username" type="text" class="Input"></td>
    </tr>
    <tr>
      <td align="right">Password</td>
      <td><input name="Password" type="password" class="Input"></td>
    </tr>
    <tr>
      <td> </td>
      <td><input name="Submit" type="submit" value="Login" class="Button3"></td>
    </tr>
  </table>
</form>

</body>
</html>