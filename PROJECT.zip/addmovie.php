<?php
//echo 'file found';

$servername = "localhost";
$username = "imahi1";
$password = "imahi1";
$dbname = "imahi1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$imagePath  = "upload/";
//$image = $_POST['imageupload'];
//Stores the filename as it was on the client computer.
$imagename = $_FILES['imageupload']['name'];
//Stores the filetype e.g image/jpeg
$imagetype = $_FILES['imageupload']['type'];
//Stores any error codes from the upload.
$imageerror = $_FILES['imageupload']['error'];
//Stores the tempname as it is given by the host when uploaded.
$imagetemp = $_FILES['imageupload']['tmp_name'];
// if(move_uploaded_file($imagetemp, $imagePath . $imagename)) {
//     echo "Sussecfully uploaded your image.";
// }

try{
    if(move_uploaded_file($imagetemp, $imagePath . $imagename)) {
        echo "Sussecfully uploaded your image.";
    }
}catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}

$sql = "INSERT INTO Movie (moviename, genre, year, book, mystatus, description, comments, file_name,reg_date,status)
 VALUES('$_POST[moviename]','$_POST[genre]','$_POST[year]','$_POST[book]','$_POST[mystatus]','$_POST[description]','$_POST[comments]','$imagename',now(),1)";
echo $imagetemp, $imagePath . $imagename;
    if(mysqli_query($conn, $sql)){
 		  echo 'Data inserted successfully';
 		} else{
 		  echo 'Error: '.mysqli_error($conn);
 		}



?>