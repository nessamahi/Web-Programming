<!DOCTYPE html>
<html>
<head>
<title>Home</title>
    <style>
	 body{
	background : black;
	color : white;
	}
	
        #main-nav {
            padding: 50px;
            margin: 0px;
        }

        .header__container {
            display: flex;
            justify-content: space-between;
            background-color: white;
        }

        .header-logo-link > img {
            width: 50px;
        }

        nav.header-nav {
            display: flex;
        }

        .header-home {
            padding: 12px 30px;
            border: none;
            margin-right: 20px;
            cursor: pointer;
            text-decoration: none;
            color: black;
        }

        .header-admin {
            padding: 12px 30px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            color: black;
        }

        #main-content {
            margin-top: 15px;
            padding: 50px;
        }

        .main-content__header {
            display: flex;
            justify-content: center;
        }

        .box-design {
            width: 150px;
            padding: 10px 12px;
            height: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            border: 1px solid black;
			
        }

        .main-content__details-and-search__wrapper {
            margin-top: 15px;
            display: flex;
            justify-content: space-around;
        }

        .main-content__search {
            display: flex;
        }

        .search-field.box-design {
            padding: 16px 13px;
            width: 200px;
        }

        .search-submit {
            height: 34px;
            margin-left: 10px;
            padding: 6px 12px;
            background: lightgrey;
            border: 1px solid black;
            cursor: pointer;
        }

        .movie-slider {
            margin-top: 50px;
            display: flex;
            justify-content: center;
        }

        .movie-container {
            padding: 30px 50px;
            border: 1px solid black;
            background: #f7f7f7;
            width: auto !important;
			color: black;
        }

        .movie-name {
            margin: 18px 20px;
            font-size: 18px;
            font-weight: 600;
			color:black;
        }

        .movie-details {
            margin: 0 20px;
            display: flex;
			color: black;
        }

        .movie-left-box {
            margin-right: 30px;
        }

        .movie-left-box > img {
            width: 200px;
        }

        .movie-description {
            text-align: left;
            margin-bottom: 25px;
			color:black;
        }

        .movie-details-container {
            display: flex;
            justify-content: space-around;
            margin-bottom: 24px;
			color: black;
        }

        .movie-my-status {
            margin-bottom: 25px;
			color:black;
        }


    </style>
    
</head>

<body>
<?php
$servername = "localhost";
$username = "imahi1";
$password = "imahi1";
$dbname = "imahi1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM  Movie";
//$result = $conn->query($sql);
$result = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);
//$all_data = mysqli_fetch_assoc($result);
//print_r($all_data)

?>
<div id="main-nav">
    <div class="header__container">
        <div class="header-logo">
            <a class="header-logo-link" title="Logo" aria-label="Logo"><img
                        src="catlogo.png"></a>
        </div>

        <div class="header-nav-container">
            <nav class="header-nav" aria-label="Navigation" role="navigation">
                <a class="header-home" href="homePage.php">Home</a>
                <a class="header-admin" href="login.php">Admin</a>
            </nav>
        </div>
    </div>
</div>

<div id="main-content">
    <div class="main-content__header">
        <div class="main-content__header-title box-design">Movie Blog</div>
    </div>

    <br>
    
    <?php  foreach ($result as $row) {
        //echo $all_data[moviename]
    ?>
        <div class="movie-container">
            <div class="movie-name"><?php echo $row['moviename'];?></div>
            <div class="movie-details">
                <div class="movie-left-box">
                    <img class="movie-image" src= <?php echo 'https://codd.cs.gsu.edu/~imahi1/Project/upload/'.$row['file_name'];?>>
                </div>
                <div class="movie-right-box">
                        <div class="movie-description"><?php echo $row['description'];?> </div>
                        <div class="movie-details-container">
                            <div class="movie-genre">Genre: <span class="movie-genre-name"><?php echo $row['genre'];?></span></div>
                            <div class="movie-year">Year: <span class="movie-year-is"><?php echo $row['year'];?></span></div>
                            <div class="movie-book">Book: <span class="movie-has-book"><?php echo $row['book'];?></span></div>
                        </div>
                        <div class="movie-my-status">My Status: <span class="movie-has-status"><?php echo $row['mystatus'];?></span></div>
                        <div class="movie-my-comments">Comments: <?php echo $row['comments'];?>
                        </div>
                    </div></div>
            </div>

        




    
    <?php }?>
</div>


</body>
</html>