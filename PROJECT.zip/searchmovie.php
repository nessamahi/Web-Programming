
<?php
$servername = "localhost";
$username = "imahi1";
$password = "imahi1";
$dbname = "imahi1";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT * FROM Movie WHERE moviename='$_POST[moviename]'";
if($result = mysqli_query($conn, $sql)){
if(mysqli_num_rows($result) > 0){
echo "<table>";
echo "<tr>";
echo "<th>  Movie_Name  </th>";
echo "<th>  Genre  </th>";
echo "<th>  Year  </th>";
echo "<th>  Book  </th>";
echo "</tr>";
while($row = mysqli_fetch_array($result)){
echo "<tr>";
echo "<td>" . $row['moviename'] .   "</td>";
echo "<td>"   . $row['genre'] .   "</td>";
echo "<td>"   . $row['year'] .   "</td>";
echo "<td>"   . $row['book'] .   "</td>";

  
  
echo "</tr>";
}
echo "</table>";


// Close result set
mysqli_free_result($result);

echo "<a href= https://codd.cs.gsu.edu/~imahi1/Project/homePage.php> Deatils </a>";
}else{
echo "No records matching your query were found.";
  
}
}
else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>

